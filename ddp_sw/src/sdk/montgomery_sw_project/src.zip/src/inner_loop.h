/*
 * asm_func.h
 *
 *  Created on: May 13, 2016
 *      Author: dbozilov
 */

#ifndef INNER_LOOP_H_
#define INNER_LOOP_H_

#include <stdint.h>

void inner_loop(uint32_t *C, uint32_t *S, uint32_t *t, uint32_t *a, uint32_t *b, uint32_t m, uint32_t *n, uint32_t i, uint32_t j);

#endif /* INNER_LOOP_H_ */
