#include <stdint.h>                                              
                                                                 
// This file's content is created by the testvector generator    
// python script for seed = 42                    
//                                                               
//  The variables are defined for the RSA                        
// encryption and decryption operations. And they are assigned   
// by the script for the generated testvector. Do not create a   
// new variable in this file.                                    
//                                                               
// When you are submitting your results, be careful to verify    
// the test vectors created for seed = 2017.1, to 2017.5         
// To create them, run your script as:                           
//   $ python testvectors.py crtrsa 2017.1                       
                                                                 
// message                                                       
uint32_t M[32] = {0x904f75fe, 0xf0617922, 0x14f5354b, 0x73d34d54, 0x827b9cf9, 0x287b6b06, 0xd839ac3f, 0x640ea6f5, 0xfad3d2c0, 0xd33b5728, 0x89bab661, 0x1a6abff9, 0x8def855a, 0xc96b1c2c, 0x16cfac3a, 0x6f1c7380, 0x20d44883, 0x29be2107, 0x5fc9ada4, 0xa49b998e, 0x6a0d1d4e, 0x38f6cecd, 0x2f36c87d, 0xf94fb8ee, 0x72fa519b, 0xf84a3304, 0xd6d48607, 0x6a6f8b72, 0x7e502bed, 0x79489b6d, 0xe8d15db6, 0x8e295b40};                 
                                                                 
// prime p and q                                                 
uint32_t p[16] = {0x1ce7ee53, 0x7e26ba5a, 0xc7826a5d, 0x4036e369, 0x285c396e, 0xb50dbec3, 0xfde70a5d, 0x5ef6bc27, 0x5e961bf3, 0x88992b2b, 0xf4d94c5a, 0xee8b5f7c, 0x4640dff4, 0x7be5f6e1, 0x9c3c5d6a, 0xa4bedec3};                 
uint32_t q[16] = {0xc7c5084f, 0xf37e959a, 0x86532d27, 0xa4156a1a, 0xe860724d, 0x4549aadc, 0x3782c76f, 0x0a76a908, 0xc9d8ad17, 0x5a26141f, 0x55186175, 0x50deba9a, 0xc6a9e3f7, 0xf311b542, 0xbdc45b8d, 0xf51a879a};                 
                                                                 
// modulus                                                       
uint32_t N[32]       = {0x15e4239d, 0x0eac8861, 0xbe43c182, 0x15b437b7, 0x51c34142, 0x0495225e, 0xbd55010b, 0x2c99e2f1, 0x79f4a773, 0x699808ab, 0x318bcc0e, 0x47063f22, 0xfab5a5bc, 0xa796f7fa, 0xae446381, 0x6b9aa667, 0xdb42020e, 0x1e45fa3e, 0xdcbcd67a, 0xc951bf16, 0x782ce619, 0x9e2ffa98, 0x5cf22f1c, 0xe7f7afb6, 0x85da6873, 0x64c6b0e1, 0xb2c509a4, 0xf10d50ff, 0x82f1d716, 0x61d00041, 0x10ce141c, 0x9dbbbdd8};           
uint32_t N_prime[32] = {0x9c7d854b, 0x9e1c748e, 0xe2730498, 0x8ca370ef, 0x134f010a, 0x946b0b13, 0xa6ee5585, 0x5d5cc4b6, 0xcb57e5f4, 0xb5427166, 0x8de75b9e, 0x4c97380b, 0x42b3530f, 0x524e211c, 0xa5b64e57, 0xc5ab1370, 0x426ab2fc, 0xae7e3abe, 0xc403fed7, 0xc849fde3, 0x85dc3a22, 0x9e2786bf, 0xaefc5844, 0x26c19ead, 0x5506d95d, 0x36474764, 0x400c348c, 0x96e1bc25, 0x30f0ebd7, 0x6ed2ed23, 0x2be9f052, 0x482ae715};     
                                                                 
// encryption exponent                                           
uint32_t e[32] = {0x000088ed};                  
uint32_t e_len = 16;                                             
                                                                 
// decryption exponent, reduced to p and q                       
uint32_t d_p[16] = {0x4b8240bd, 0x18809121, 0x4c46fe1d, 0xe39359ad, 0x36cbbb41, 0xa4736488, 0xe7246cf3, 0xedb94996, 0x70d7c0ad, 0x2b79cf1c, 0x3481def6, 0xa3b62e1c, 0x16b44ae6, 0x2b5200cc, 0x7dd461ef, 0x80df0a59};             
uint32_t d_q[16] = {0xfa347bb3, 0xa761a948, 0xdc89c618, 0x4c221685, 0xaae01fb2, 0xeafc71e4, 0xecdd65e3, 0x529a3856, 0x3f226f3b, 0xd3c399cf, 0x841ed5f1, 0x2d61e241, 0xb1927517, 0x51635407, 0xde0748e6, 0xe655f31f};             
uint32_t d_p_len =  511;   
uint32_t d_q_len =  512;   
                                                                 
// x_p and x_q                                                   
uint32_t x_p[32] = {0x0f298257, 0xab23f40c, 0x01c6b419, 0xcbb06425, 0xde70a9f2, 0xcfd5dda8, 0x9dcfd568, 0x66bfce91, 0xddd58102, 0x6c32b140, 0x741d8cfc, 0xbda8a347, 0x1f1a716e, 0xf419981f, 0x556f9787, 0x27b2d50c, 0xfec7c2c5, 0xf7c76701, 0xdf16b681, 0x12c51853, 0x6740782e, 0x2ee6af59, 0xcfa8a87a, 0xb9b160d7, 0x27450d50, 0x3fcdf22c, 0x16911e22, 0x3bedc59e, 0x2ec76898, 0xe3b966d0, 0xa8b4e1f9, 0x8cecbdcd};             
uint32_t x_q[32] = {0x06baa147, 0x63889455, 0xbc7d0d68, 0x4a03d392, 0x7352974f, 0x34bf44b5, 0x1f852ba2, 0xc5da1460, 0x9c1f2670, 0xfd65576a, 0xbd6e3f11, 0x895d9bda, 0xdb9b344d, 0xb37d5fdb, 0x58d4cbf9, 0x43e7d15b, 0xdc7a3f49, 0x267e933c, 0xfda61ff8, 0xb68ca6c2, 0x10ec6deb, 0x6f494b3f, 0x8d4986a2, 0x2e464ede, 0x5e955b23, 0x24f8beb5, 0x9c33eb82, 0xb51f8b61, 0x542a6e7e, 0x7e169971, 0x68193222, 0x10cf000a};             
                                                                 
// R mod p, and R mod q, (R = 2^512)                             
uint32_t Rp[16] = {0xe31811ad, 0x81d945a5, 0x387d95a2, 0xbfc91c96, 0xd7a3c691, 0x4af2413c, 0x0218f5a2, 0xa10943d8, 0xa169e40c, 0x7766d4d4, 0x0b26b3a5, 0x1174a083, 0xb9bf200b, 0x841a091e, 0x63c3a295, 0x5b41213c};               
uint32_t Rq[16] = {0x383af7b1, 0x0c816a65, 0x79acd2d8, 0x5bea95e5, 0x179f8db2, 0xbab65523, 0xc87d3890, 0xf58956f7, 0x362752e8, 0xa5d9ebe0, 0xaae79e8a, 0xaf214565, 0x39561c08, 0x0cee4abd, 0x423ba472, 0x0ae57865};               
                                                                 
// R^2 mod p, and R^2 mod q, (R = 2^512)                         
uint32_t R2p[16] = {0x84e41c8c, 0x12be19ce, 0x8f48e7d3, 0x3abbb5c4, 0x6eec3fa1, 0x6d5cee9e, 0x4affa98d, 0x8a9f82fa, 0xd7c42b86, 0x4b20bc77, 0xf81212ea, 0x3cc851cf, 0xd755a069, 0x6ecd1257, 0x94bb8d00, 0x26834364};             
uint32_t R2q[16] = {0xae43b5bd, 0x44ef3363, 0x2d31b9d5, 0x947bc766, 0xbf3947e7, 0xf00ed7cd, 0x57b3b722, 0xb8645422, 0x716c98bf, 0x439cbdf9, 0x05bc3b2a, 0xcf83222d, 0x81d38605, 0x8c135d62, 0xd361309a, 0x2b7194aa};             
                                                                 
// R mod N, and R^2 mod N, (R = 2^1024)                          
uint32_t R_1024[32]  = {0xea1bdc63, 0xf153779e, 0x41bc3e7d, 0xea4bc848, 0xae3cbebd, 0xfb6adda1, 0x42aafef4, 0xd3661d0e, 0x860b588c, 0x9667f754, 0xce7433f1, 0xb8f9c0dd, 0x054a5a43, 0x58690805, 0x51bb9c7e, 0x94655998, 0x24bdfdf1, 0xe1ba05c1, 0x23432985, 0x36ae40e9, 0x87d319e6, 0x61d00567, 0xa30dd0e3, 0x18085049, 0x7a25978c, 0x9b394f1e, 0x4d3af65b, 0x0ef2af00, 0x7d0e28e9, 0x9e2fffbe, 0xef31ebe3, 0x62444227};     
uint32_t R2_1024[32] = {0x1f402a85, 0x29efaa76, 0x4e6d7806, 0x683be2a2, 0x92dfbf92, 0x779029ae, 0x66ca752e, 0x811b581d, 0xad16e3b2, 0x61e63689, 0x6e098f02, 0x422c9abe, 0x06eb6b3d, 0x52b80105, 0x280dd0aa, 0xff727bf7, 0xb40766a7, 0x1d63adee, 0x30defe27, 0xaefd67dd, 0x2f660278, 0x37d525da, 0xf44d402f, 0x61cabdf1, 0xd7f66f3d, 0x7520ec15, 0xaeaa1b01, 0x0ac38f97, 0xa5973ee1, 0x91ee4fab, 0x74ac3e71, 0x30a135b4};     
                                                                 
// One                                                           
uint32_t One[32] = {1,0};                                          