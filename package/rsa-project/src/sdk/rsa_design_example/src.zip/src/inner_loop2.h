/*
 * asm_func.h
 *
 *  Created on: May 13, 2016
 *      Author: dbozilov
 */

#ifndef INNER_LOOP2_H_
#define INNER_LOOP2_H_

#include <stdint.h>


void inner_loop2(uint32_t *C_res, uint32_t *S_res, uint32_t *t, uint32_t *a, uint32_t *b, uint32_t m, uint32_t *n, uint32_t i, uint32_t SIZE);



#endif /* INNER_LOOP_H2_ */

