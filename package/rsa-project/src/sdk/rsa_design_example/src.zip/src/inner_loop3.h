/*
 * asm_func.h
 */

#ifndef INNER_LOOP3_H_
#define INNER_LOOP3_H_

#include <stdint.h>

void inner_loop3(uint32_t *C, uint32_t i, uint32_t *t, uint32_t *a, uint32_t *b, uint32_t m, uint32_t *n);

#endif /* INNER_LOOP3_H_ */
